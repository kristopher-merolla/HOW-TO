# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

import bcrypt # for encrypting passwords

# Create your models here.
class UserManager(models.Manager):
	def register_user(self, postData):
		# grab the values from our postData dictionary
		name = postData['name']
		username = postData['username']
		password = postData['password']
		password_confirm = postData['password_confirm']
		date_hired = postData['date_hired']
		# Name and Username need to be at least 2 characters, otherwise error
		if (len(name) < 2 or len(username) < 2):
			message = {
				"message":"<p style='color:red;'> NAME / USERNAME FIELD MUST BE AT LEAST 2 CHARACTERS </p> "
			}
			return [False, message]
		# Name needs to be only alpha (no numbers or special characters)
		if (not(name.replace(" ","").isalpha())):
			message = {
				"message":"<p style='color:red;'> NAME FIELD CANT CONTAIN NUMBERS OR SPECIAL CHARACTERS </p> "
			}
			return [False, message]
		try: # check if the username exists and if not, set the user to None
			user = User.objects.get(username=username)
		except User.DoesNotExist:
			user = None
		if (user == None): # if the username is NOT in the database...
			if (password == password_confirm):
				if (len(password) >= 8):
					# encrypt the password
					hashed_pw = bcrypt.hashpw(postData['password'].encode('utf-8'), bcrypt.gensalt())
					# build and execute the SQL insert for a new user creation
					user = User.objects.create(name=name,username=username,password=hashed_pw,date_hired=date_hired)
					# if all validations are met and the data is updated, redirect to the home page for login
					message = {
						"message":"<p style='color:green;'> New User Registered! Please login using your new username and pw.</p> "
					}
					return [True, message]
				else: # display error message password too short
					message = {
						"message":"<p style='color:red;'> PASSWORD TOO SHORT </p> "
					}
					return [False, message]
			else: # display error message password not matching password confirmation
				message = {
					"message":"<p style='color:red;'> PASSWORDS DO NOT MATCH </p> "
				}
				return [False, message]
		else: # if the username IS in the database...
			message = {
				"message":"<p style='color:red;'> USERNAME ALREADY EXISTS </p> "
			}
			return [False, message]

	def login_successful(self, postData):
		# grab the username and password from the postData
		login_username = postData['username']
		login_password = postData['password']
		try: # check if the user exists and if not, set the user to None
			user = User.objects.get(username=login_username)
		except User.DoesNotExist:
			user = None
		if (user != None): # username IS in the database
			stored_hash = user.password
			input_hash = bcrypt.hashpw(login_password.encode(), stored_hash.encode())
			# validate login credentials here
			if (input_hash == user.password): # passwords match, login
				return [True, user]
			else: # display error message password invalid (does not match database entry)
				message = {
					"message":"<p style='color:red;'> INVALID PASSWORD </p> "
				}
				return [False, message]
		else:
			message = {
				"message":"<p style='color:red;'> USERNAME NOT REGISTERED </p> "
			}
			return [False, message]

class WishlistManager(models.Manager):
	def wishlist_add(self, postData):
		# grab the item from the user
		new_item = postData['item']
		active_user = postData['active_user']
		# check that the item is at least 4 characters long
		if (len(new_item) < 4):
			message = {
				"message":"<p style='color:red;'> ITEM/PRODUCT MUST BE AT LEAST 4 CHARACTERS </p> "
			}
			return [False, message]
		else:
			user = User.objects.get(username=active_user)
			item_check = Wishlist.objects.filter(item=new_item).first()
			print item_check
			if (item_check == None):
				# create the item with the user_id as the id of the user
				self.create(item=new_item, user=user)
				item_added = Wishlist.objects.filter(item=new_item).first()
				item_added.wishers.add(user)
				return [True]
			else:
				# add the user as a wisher
				item_added = Wishlist.objects.filter(item=new_item).first()
				item_added.wishers.add(user)
				return [True]

# DATABASE TABLES BELOW:
class User(models.Model):
	name = models.CharField(max_length=255)
	username = models.CharField(max_length=255)
	password = models.CharField(max_length=255)
	date_hired = models.DateTimeField(auto_now_add=False)
	created_at = models.DateTimeField(auto_now_add=True)
	updated_at = models.DateTimeField(auto_now=True)
	objects = UserManager()

	def __unicode__(self):
		return "id:" + str(self.id) + ", username:" + self.username

class Wishlist(models.Model):
	item = models.CharField(max_length=255)
	user = models.ForeignKey(User)
	wishers = models.ManyToManyField(User, related_name="wisheditems") # many to many field, a list of user objects
	created_at = models.DateTimeField(auto_now_add=True)
	updated_at = models.DateTimeField(auto_now=True)
	objects = WishlistManager()