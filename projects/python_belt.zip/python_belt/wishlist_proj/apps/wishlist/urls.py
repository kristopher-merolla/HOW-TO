from django.conf.urls import url
from . import views

urlpatterns = [
	url(r'^$', views.index),
	url(r'^register$', views.register),
	url(r'^login$', views.login),
	url(r'^register_user$', views.new_login),
	url(r'^wishlist$', views.wishlist),
	url(r'^logout$', views.logout),
	url(r'^add_item$', views.add_item),
	url(r'^new_item$', views.new_item),
	url(r'^add/(?P<user_id>\d+)/(?P<item_id>\d+)$', views.add_to_wishlist),
	url(r'^wish_items/(?P<item_id>\d+)$', views.wish_items),
	url(r'^delete/(?P<item_id>\d+)$', views.delete_item),
	url(r'^remove/(?P<item_id>\d+)$', views.remove_item)
]