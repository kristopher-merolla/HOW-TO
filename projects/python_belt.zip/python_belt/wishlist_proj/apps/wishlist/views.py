# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render, redirect, HttpResponse

from django.db.models import Count

from .models import User, Wishlist

# Create your views here.
def index(request): # login / register (index) page
	if (request.session.get('active_user') == None):
		return render(request, 'wishlist/index.html')
	else:
		request.session['active_user'] = None
		return render(request, 'wishlist/index.html')

def register(request): # page to register new users
	return render(request, 'wishlist/register.html')

def logout(request): # when a user clicks the logout button, clear active user session and redirect to index page
	request.session['active_user'] = None
	return render(request, 'wishlist/index.html')

def add_item(request): # link to add a new item to the wishlist
	if (request.session.get('active_user') == None):
		return redirect('/')
	return render(request, 'wishlist/add_item.html')

def delete_item(request, item_id): # link to delete an item
	if (request.session.get('active_user') == None):
		return redirect('/')
	item = Wishlist.objects.get(id=item_id)
	item.delete()
	return redirect('/wishlist')

def remove_item(request, item_id): # link to remove an item
	if (request.session.get('active_user') == None):
		return redirect('/')
	active_user_id = User.objects.filter(username=request.session['active_user']).first().id
	item = Wishlist.objects.filter(id=item_id).first()
	active_user = User.objects.get(id=active_user_id)
	item.wishers.remove(active_user)
	print "got past that", item_id, "-", item, "-", active_user
	return redirect('/wishlist')

def wish_items(request, item_id):
	item_name = Wishlist.objects.get(id=item_id).item
	item = Wishlist.objects.get(id=item_id)
	context = {
		"item_name":item_name,
		"item":item
	}
	return render(request, 'wishlist/wish_item.html', context)

def add_to_wishlist(request, user_id, item_id):
	active_user_id = User.objects.filter(username=request.session['active_user']).first().id
	if (user_id == active_user_id):
		return redirect('/wishlist')
	else:
		item = Wishlist.objects.filter(id=item_id).first()
		active_user = User.objects.get(id=active_user_id)
		item.wishers.add(active_user)
		return redirect('/wishlist')

def new_item(request): # for adding a new item once the item is added on the add_item page
	postData = {
		"item":request.POST['item'],
		"active_user":request.session['active_user']
	}
	model_resp = Wishlist.objects.wishlist_add(postData)
	if (model_resp[0] == True): # new item added / user added as "wisher" for the item already existing
		return redirect('/wishlist')
	else:
		return render(request, 'wishlist/add_item.html', model_resp[1]) # model_resp[1] is the error_message

def wishlist(request): # page once user is logged in
	if (request.session.get('active_user') == None):
		return redirect('/')
	# try:
	user = User.objects.filter(username=request.session['active_user'])
	context = {
		"user_wishlist": Wishlist.objects.filter(wishers=user).order_by('id'),
		"other_wishlist": Wishlist.objects.exclude(wishers=user).order_by('id'),
		"currentuser": User.objects.get(username=request.session['active_user']).name
	}
	return render(request, 'wishlist/wishlist.html', context)

	# PAGE TO LOGIN EXISTING USER
def login(request):
	# grab the data entered in the login form (username and password) and put in the postData dictionary
	postData = {
		"username": request.POST['username'],
		"password": request.POST['password'] # password needs to be hashed here, use md5 and a salt	
	}
	# check the login success for username and password validations
	model_resp = User.objects.login_successful(postData)
	if model_resp[0] == True: # user login was successful (passed and username validations)
		request.session['active_user'] = model_resp[1].username # model_resp[1] here is the user (active user)
		request.session['active_user_name'] = model_resp[1].name
		return redirect('/wishlist')
	else: # user login was NOT successful
		return render(request, 'wishlist/index.html', model_resp[1]) # model_resp[1] is the error_message

# PAGE TO REGISTER NEW USER
def new_login(request):
	# grab the data entered in the registration form and put it in the postData dictionary
	postData = {
		"name": request.POST['name'],
		"username" : request.POST['username'],
		"password" : request.POST['password'],
		"password_confirm" : request.POST['password_confirmation'],
		"date_hired" : request.POST['date_hired']
	}
	# check the registration success and if successful, return to login page for user to log in
	model_resp = User.objects.register_user(postData)
	if model_resp[0] == True: # user registration was successful
		return render(request,'wishlist/index.html', model_resp[1]) # model_resp[1] is the registration_success message
	else: # user registration was NOT successful
		return render(request, 'wishlist/register.html', model_resp[1]) # model_resp[1] is the error_message